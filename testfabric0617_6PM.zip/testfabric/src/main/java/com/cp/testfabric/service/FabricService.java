package com.cp.testfabric.service;

public interface FabricService {
    
    

}