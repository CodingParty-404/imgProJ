package com.cp.donga.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CommonController {

    @GetMapping("/index")
    public void index(){

    }

    @GetMapping("/index2")
    public void index2(){

    }

    @GetMapping("/index3")
    public void index3(){

    }

    @GetMapping("/index4")
    public void index4(){

    }

    @GetMapping("/index5")
    public void index5(){

    }

    @GetMapping("/index6")
    public void index6(){

    }

    @GetMapping("/index7")
    public void index7(){

    }
    
}